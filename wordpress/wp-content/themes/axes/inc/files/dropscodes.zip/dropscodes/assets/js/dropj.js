/* 
 * @package Wordpress.Plugins
 * @subpackage Dropscodes
 * @since Dropscodes 1.0.1
 * @author TDGR / Pixeldrops.net
 */

(function($) {
	
	"use strict";
		
	// all script calls are in theme's function.js

})(jQuery);
<?php
/*
Plugin Name: Dropscodes
Plugin URI: http://themeforest.net/user/tdgr
Description: Shortcodes plugin for TDGR themes
Author: Pixeldrops / TDGR
Author URI: http://themeforest.net/user/tdgr
Version: 1.1
License: GNU General Public License version 3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html
*/

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

require_once( dirname(__FILE__) . '/scripts.php' ); 
require_once( dirname(__FILE__) . '/functions.php' );

?>